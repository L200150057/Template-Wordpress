==Description==

Theme Name: Belajar_V1.0
Theme URI: hhttps://github.com/L200150057
Author: Muhammad Yulianto
Author URI: https://github.com/L200150057
Description: Simple Bootstrap Wordpress Theme
Version: 1.0
Tags: two-columns, blog
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: Belajar_V1.0

==Help==
Please Check Help Folder, if not helping please mail to Myulianto71@gmail.com