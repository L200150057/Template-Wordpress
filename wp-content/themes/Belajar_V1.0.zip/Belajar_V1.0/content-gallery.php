<div class="blog-post post-gallery">
  <h2><?php the_title(); ?></h2>
  <?php the_content(); ?>
</div>
